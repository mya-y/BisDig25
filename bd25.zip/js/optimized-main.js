// js/optimized-main.js - Untuk HP Chrome
console.log('📱 HP Optimized Main');

// ============================================
// 1. RENDER STRUKTUR SUPER CEPAT (HP FRIENDLY)
// ============================================
function renderStrukturHP() {
  console.time('⏱️ Render Struktur HP');
  
  const container = document.getElementById('strukturGrid');
  if (!container) return;
  
  // Kosongkan & langsung render
  container.innerHTML = '';
  
  // Cek data
  if (!DATA || !DATA.struktur || DATA.struktur.length === 0) {
    container.innerHTML = '<p style="text-align:center;padding:40px;color:#64748b;">Struktur sedang diatur</p>';
    return;
  }
  
  // RENDER LANGSUNG TANPA EFEK
  let html = '';
  
  // Ambil hanya 8 pertama untuk HP
  const strukturToShow = DATA.struktur.slice(0, 8);
  
  strukturToShow.forEach((item, index) => {
    const initial = item.initial || (item.nama ? item.nama.charAt(0).toUpperCase() : '?');
    
    html += `
      <div class="anggota-card" style="
        opacity: 1 !important;
        transform: none !important;
        animation: none !important;
        border: 1px solid rgba(56, 189, 248, 0.2);
        border-radius: 12px;
        overflow: hidden;
        background: rgba(30, 41, 59, 0.9);
        min-height: 150px;
      ">
        <div style="
          width: 100%;
          height: 120px;
          ${item.foto && item.foto !== 'null' ? 
            `background-image: url('${item.foto}');
             background-size: cover;
             background-position: center;` : 
            `background: linear-gradient(135deg, #334155, #475569);
             display: flex;
             align-items: center;
             justify-content: center;
             font-size: 2.5em;
             color: #94a3b8;`
          }
          border-bottom: 1px solid rgba(56, 189, 248, 0.1);
        ">
          ${!item.foto || item.foto === 'null' ? initial : ''}
        </div>
        <div style="padding: 12px; text-align: center;">
          <h4 style="margin:0 0 4px 0;font-size:0.95em;color:#e5e7eb;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
            ${item.nama || 'Anggota'}
          </h4>
          <p style="margin:0;font-size:0.8em;color:#38bdf8;">${item.jabatan || 'Kelas'}</p>
        </div>
      </div>
    `;
  });
  
  container.innerHTML = html;
  
  // Add "Lihat semua" jika lebih dari 8
  if (DATA.struktur.length > 8) {
    container.innerHTML += `
      <div class="anggota-card" style="
        opacity:1; 
        grid-column: 1 / -1;
        text-align:center;
        padding:20px;
        background:rgba(56, 189, 248, 0.1);
        border:1px dashed #38bdf8;
      ">
        <div style="font-size:2em;margin-bottom:10px;">👥</div>
        <h4 style="margin:0 0 5px 0;color:#e5e7eb;">+${DATA.struktur.length - 8} Anggota Lainnya</h4>
        <p style="margin:0;color:#94a3b8;font-size:0.9em;">Total ${DATA.struktur.length} Anggota Kelas</p>
      </div>
    `;
  }
  
  console.timeEnd('⏱️ Render Struktur HP');
  console.log(`✅ Rendered ${strukturToShow.length} struktur on HP`);
}

// ============================================
// 2. RENDER GALERI UNTUK HP
// ============================================
function renderGaleriHP() {
  const fotoGrid = document.getElementById('fotoTerbaruGrid');
  const kenanganGrid = document.getElementById('kenanganPreview');
  
  if (!DATA || !DATA.galeri) return;
  
  // Foto terbaru (max 4)
  if (fotoGrid) {
    const fotoTerbaru = DATA.galeri
      .filter(item => item.category === 'foto-terbaru')
      .slice(0, 4);
    
    if (fotoTerbaru.length > 0) {
      let html = '';
      fotoTerbaru.forEach(item => {
        html += `
          <div class="photo-card" style="
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid rgba(56, 189, 248, 0.2);
          ">
            <img src="${item.url}" alt="${item.title || ''}" 
                 loading="lazy" 
                 style="width:100%;height:120px;object-fit:cover;">
            <div style="padding:8px;text-align:center;">
              <p style="margin:0;font-size:0.85em;color:#e5e7eb;">${item.title || 'Foto'}</p>
            </div>
          </div>
        `;
      });
      fotoGrid.innerHTML = html;
    }
  }
  
  // Kenangan (max 3)
  if (kenanganGrid) {
    const kenangan = DATA.galeri
      .filter(item => item.category === 'kenangan')
      .slice(0, 3);
    
    if (kenangan.length > 0) {
      let html = '';
      kenangan.forEach(item => {
        html += `
          <div style="
            min-width: 200px;
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid rgba(56, 189, 248, 0.2);
            background: rgba(30, 41, 59, 0.9);
          ">
            ${item.type === 'video' ? 
              `<div style="position:relative;">
                 <video src="${item.url}" style="width:100%;height:140px;object-fit:cover;" muted></video>
                 <div style="position:absolute;top:5px;right:5px;background:rgba(0,0,0,0.7);color:white;padding:2px 6px;border-radius:4px;font-size:0.7em;">🎥</div>
               </div>` : 
              `<img src="${item.url}" alt="${item.title || ''}" 
                   loading="lazy" 
                   style="width:100%;height:140px;object-fit:cover;">`
            }
            <div style="padding:10px;">
              <p style="margin:0 0 5px 0;font-size:0.9em;color:#e5e7eb;">${item.title || 'Kenangan'}</p>
              ${item.caption ? `<p style="margin:0;font-size:0.8em;color:#94a3b8;">${item.caption}</p>` : ''}
            </div>
          </div>
        `;
      });
      kenanganGrid.innerHTML = html;
    }
  }
}

// ============================================
// 3. INITIALIZE FOR HP
// ============================================
document.addEventListener('DOMContentLoaded', function() {
  console.log('📱 HP Mode Activated');
  
  // RENDER SEMUA LANGSUNG (tanpa tunggu)
  setTimeout(() => {
    // 1. Struktur FIRST (paling penting)
    renderStrukturHP();
    
    // 2. Galeri
    setTimeout(renderGaleriHP, 50);
    
    // 3. Hide loading screen faster on HP
    setTimeout(() => {
      const loading = document.getElementById('globalLoading');
      if (loading) {
        loading.style.transition = 'opacity 0.3s';
        loading.style.opacity = '0';
        setTimeout(() => {
          loading.style.display = 'none';
        }, 300);
      }
    }, 800);
    
    // 4. Force all sections visible
    document.querySelectorAll('section').forEach(section => {
      section.style.opacity = '1';
      section.style.transform = 'none';
    });
    
    console.log('✅ HP rendering complete');
  }, 100);
});

// ============================================
// 4. SIMPLE NAVIGATION FOR HP
// ============================================
window.toggleMenu = function() {
  const menu = document.getElementById('navMenu');
  if (menu) menu.classList.toggle('show');
};

window.scrollToSection = function(id) {
  const element = document.getElementById(id);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
    const menu = document.getElementById('navMenu');
    if (menu) menu.classList.remove('show');
  }
};