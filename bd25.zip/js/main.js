// js/main.js - FIXED VERSION
// Index page JavaScript untuk BD25

document.addEventListener('DOMContentLoaded', async function() {
  console.log('🚀 Website BD25 loaded');
  
  // ============================================
  // FUNGSI UTILITY
  // ============================================
  
  function toggleMenu() {
    const menu = document.getElementById('navMenu');
    if (menu) menu.classList.toggle('show');
  }
  
  function scrollToSection(id) {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      const menu = document.getElementById('navMenu');
      if (menu) menu.classList.remove('show');
    }
  }
  
  // Glow effect untuk card
  let activeCard = null;
  function glowEffect(element) {
    if (activeCard) {
      activeCard.classList.remove('active');
    }
    element.classList.add('active');
    activeCard = element;
    
    setTimeout(() => {
      element.classList.remove('active');
      activeCard = null;
    }, 800);
  }
  
  // ============================================
  // LOAD DATA FUNCTIONS
  // ============================================
  
  async function loadFromFirebase() {
    try {
      console.log('🔥 Mencoba load dari Firebase...');
      
      if (!window.firestore || !window.db) {
        console.log('Firebase not available, using Data.js');
        return null;
      }
      
      // Load galeri dengan sorting berdasarkan tanggal (terbaru dulu)
      const galeriQuery = window.firestore.query(
        window.firestore.collection(window.db, 'galeri'),
        window.firestore.orderBy('tanggal', 'desc'),
        window.firestore.orderBy('timestamp', 'desc')
      );
      
      // Load struktur dengan sorting berdasarkan urutan
      const strukturQuery = window.firestore.query(
        window.firestore.collection(window.db, 'struktur'),
        window.firestore.orderBy('urutan', 'asc')
      );
      
      const [galeriSnap, strukturSnap] = await Promise.all([
        window.firestore.getDocs(galeriQuery),
        window.firestore.getDocs(strukturQuery)
      ]);
      
      console.log(`✅ Firebase loaded: ${galeriSnap.size} galeri, ${strukturSnap.size} struktur`);
      
      return {
        galeri: galeriSnap.docs.map(doc => ({ 
          id: doc.id, 
          ...doc.data(),
          // Ensure URL exists
          url: doc.data().url || '',
          type: doc.data().type || 'image'
        })),
        struktur: strukturSnap.docs.map(doc => ({ 
          id: doc.id, 
          ...doc.data(),
          // Ensure foto exists
          foto: doc.data().foto || '',
          initial: doc.data().initial || (doc.data().nama ? doc.data().nama.charAt(0).toUpperCase() : '?')
        }))
      };
      
    } catch (error) {
      console.error('❌ Error loading from Firebase:', error);
      return null;
    }
  }
  
  function loadFromDataJS() {
    console.log('📁 Mencoba load dari Data.js...');
    
    if (typeof DATA !== 'undefined' && DATA) {
      console.log('DATA.js found:', {
        galeri: DATA.galeri?.length || 0,
        struktur: DATA.struktur?.length || 0
      });
      
      // Sort galeri berdasarkan tanggal (terbaru dulu)
      const sortedGaleri = (DATA.galeri || []).sort((a, b) => {
        try {
          const dateA = a.tanggal ? new Date(a.tanggal) : 
                       (a.timestamp ? (a.timestamp.toDate ? a.timestamp.toDate() : new Date(a.timestamp)) : new Date(0));
          const dateB = b.tanggal ? new Date(b.tanggal) : 
                       (b.timestamp ? (b.timestamp.toDate ? b.timestamp.toDate() : new Date(b.timestamp)) : new Date(0));
          return dateB - dateA;
        } catch (e) {
          return 0;
        }
      }).filter(item => item.url); // Hanya yang punya URL
      
      // Sort struktur berdasarkan urutan
      const sortedStruktur = (DATA.struktur || []).sort((a, b) => {
        return (a.urutan || 999) - (b.urutan || 999);
      });
      
      return {
        galeri: sortedGaleri,
        struktur: sortedStruktur
      };
    }
    
    console.log('❌ DATA.js not found or empty');
    return null;
  }
  
  // ============================================
  // RENDER FUNCTIONS - FIXED VERSION
  // ============================================
  
  function renderFotoTerbaru(galeri) {
    const container = document.getElementById('fotoTerbaruGrid');
    if (!container) {
      console.error('Foto terbaru container not found');
      return;
    }
    
    console.log('📸 Rendering foto terbaru...');
    
    // Filter hanya foto terbaru dengan URL valid, ambil 4 terbaru
    const fotoTerbaru = (galeri || [])
      .filter(item => item.url && item.category === 'foto-terbaru')
      .slice(0, 4);
    
    if (fotoTerbaru.length === 0) {
      container.innerHTML = `
        <div class="no-data" style="grid-column:1/-1;">
          <div style="font-size:48px;margin-bottom:10px;">📸</div>
          <p>Belum ada foto terbaru</p>
        </div>
      `;
      return;
    }
    
    let html = '';
    fotoTerbaru.forEach((item, index) => {
      const tanggal = formatTanggal(item.tanggal || item.timestamp);
      
      html += `
        <div class="card media-item" onclick="glowEffect(this)" style="animation-delay: ${index * 0.1}s">
          ${item.type === 'video' ? 
            `<video src="${item.url}" muted loop playsinline></video>` : 
            `<img src="${item.url}" alt="${item.title || 'Foto'}" loading="lazy">`
          }
          <div style="padding:12px;">
            <h4 style="margin:0 0 5px 0;font-size:14px;color:#e5e7eb;">${item.title || 'Foto'}</h4>
            ${tanggal ? `<p style="color:#64748b;font-size:12px;margin:0;">📅 ${tanggal}</p>` : ''}
          </div>
        </div>
      `;
    });
    
    container.innerHTML = html;
    console.log(`✅ Rendered ${fotoTerbaru.length} foto terbaru`);
  }
  
  function renderKenangan(galeri) {
    const container = document.getElementById('kenanganPreview');
    if (!container) {
      console.error('Kenangan container not found');
      return;
    }
    
    console.log('💝 Rendering kenangan...');
    
    // Filter hanya kenangan dengan URL valid, ambil 4 terbaru
    const kenangan = (galeri || [])
      .filter(item => item.url && item.category === 'kenangan')
      .slice(0, 4);
    
    if (kenangan.length === 0) {
      container.innerHTML = `
        <div style="text-align:center;padding:40px;color:#64748b;width:100%;">
          <div style="font-size:48px;margin-bottom:10px;">💝</div>
          <p>Belum ada kenangan</p>
        </div>
      `;
      return;
    }
    
    let html = '';
    kenangan.forEach((item, index) => {
      const tanggal = formatTanggal(item.tanggal || item.timestamp);
      const isVideo = item.type === 'video';
      
      html += `
        <div class="card media-item" onclick="glowEffect(this)" style="width:260px;flex-shrink:0;">
          ${isVideo ? 
            `<video src="${item.url}" muted loop playsinline style="width:260px;height:180px;object-fit:cover;"></video>` : 
            `<img src="${item.url}" alt="${item.title || 'Kenangan'}" loading="lazy" style="width:260px;height:180px;object-fit:cover;">`
          }
          <div style="padding:12px;">
            <h4 style="margin:0 0 5px 0;font-size:14px;color:#e5e7eb;">${item.title || 'Kenangan'}</h4>
            ${tanggal ? `<p style="color:#64748b;font-size:12px;margin:0;">📅 ${tanggal}</p>` : ''}
          </div>
        </div>
      `;
    });
    
    container.innerHTML = html;
    console.log(`✅ Rendered ${kenangan.length} kenangan`);
  }
  
  // ============================================
  // RENDER STRUKTUR - FIXED VERSION
  // ============================================
  
  function renderStruktur(struktur) {
    const container = document.getElementById('strukturGrid');
    if (!container) {
      console.error('❌ Struktur container not found');
      return;
    }
    
    console.log('👥 Rendering struktur...');
    
    // Pastikan container visible
    container.style.opacity = '1';
    container.style.visibility = 'visible';
    container.style.display = 'grid';
    
    // Tampilkan loading state
    container.innerHTML = `
      <div class="loading-struktur">
        <div class="spinner"></div>
        <p>Memuat data struktur...</p>
      </div>
    `;
    
    // Render setelah delay kecil untuk UX
    setTimeout(() => {
      if (!struktur || struktur.length === 0) {
        container.innerHTML = `
          <div class="no-data">
            <div style="font-size:48px;margin-bottom:10px;">👥</div>
            <p>Belum ada data struktur</p>
          </div>
        `;
        return;
      }
      
      console.log(`Rendering ${struktur.length} struktur items`);
      
      // Render semua anggota
      let html = '';
      struktur.forEach((item, index) => {
        const initial = item.initial || (item.nama ? item.nama.charAt(0).toUpperCase() : '?');
        const nama = item.nama || 'N/A';
        const jabatan = item.jabatan || 'Anggota';
        
        html += `
          <div class="anggota-card" data-index="${index}">
            ${item.foto ? 
              `<img src="${item.foto}" alt="${nama}" loading="lazy" 
                   onload="this.style.opacity='1'" 
                   style="opacity:0;transition:opacity 0.3s ease;">` : 
              `<div class="anggota-placeholder">${initial}</div>`
            }
            <h4>${nama}</h4>
            <p>${jabatan}</p>
          </div>
        `;
      });
      
      container.innerHTML = html;
      
      // Force animation untuk semua card
      setTimeout(() => {
        const cards = container.querySelectorAll('.anggota-card');
        cards.forEach(card => {
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
        });
      }, 100);
      
      console.log(`✅ Successfully rendered ${struktur.length} struktur items`);
      
      // Auto-animate masuk
      setTimeout(() => {
        const cards = container.querySelectorAll('.anggota-card');
        cards.forEach((card, i) => {
          card.style.animationDelay = `${i * 0.1}s`;
        });
      }, 200);
      
    }, 300); // Loading delay
  }
  
  // Helper function untuk format tanggal
  function formatTanggal(dateInput) {
    try {
      if (!dateInput) return '';
      
      let date;
      if (typeof dateInput === 'string') {
        date = new Date(dateInput);
      } else if (dateInput.toDate) {
        date = dateInput.toDate();
      } else if (dateInput instanceof Date) {
        date = dateInput;
      } else {
        return '';
      }
      
      if (isNaN(date.getTime())) return '';
      
      return date.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });
    } catch (error) {
      console.error('Error formatting date:', error);
      return '';
    }
  }
  
  // ============================================
  // MAIN LOADING LOGIC - FIXED
  // ============================================
  
  async function loadAndRenderAllData() {
    try {
      console.log('🔄 Starting data loading process...');
      
      let data = null;
      
      // Langsung render loading state untuk struktur
      renderStruktur([]); // Kosong dulu
      
      // Coba load dari Firebase dulu (jika admin sudah login)
      if (window.firestore && window.db) {
        console.log('Trying Firebase first...');
        data = await loadFromFirebase();
      }
      
      // Jika Firebase gagal atau tidak ada data, coba dari Data.js
      if (!data) {
        console.log('Trying Data.js...');
        data = loadFromDataJS();
      }
      
      // Jika masih tidak ada data
      if (!data) {
        console.error('❌ Tidak bisa load data dari mana pun');
        
        // Tampilkan error di semua section
        const sections = {
          'fotoTerbaruGrid': '📸',
          'kenanganPreview': '💝', 
          'strukturGrid': '👥'
        };
        
        for (const [id, icon] of Object.entries(sections)) {
          const container = document.getElementById(id);
          if (container) {
            container.innerHTML = `
              <div class="error">
                <div style="font-size:48px;margin-bottom:10px;">${icon}</div>
                <p>Error memuat data</p>
                <p style="font-size:12px;color:#94a3b8;">Coba refresh halaman</p>
              </div>
            `;
          }
        }
        
        return;
      }
      
      console.log('✅ Data loaded successfully:', {
        galeri: data.galeri?.length || 0,
        struktur: data.struktur?.length || 0
      });
      
      // RENDER PENTING: STRUKTUR PERTAMA & LANGSUNG!
      renderStruktur(data.struktur);
      
      // Kemudian render yang lain
      setTimeout(() => {
        renderFotoTerbaru(data.galeri);
        renderKenangan(data.galeri);
      }, 100);
      
      // Setup scroll animation (tapi exclude struktur section)
      setTimeout(() => {
        setupScrollAnimation();
      }, 500);
      
    } catch (error) {
      console.error('❌ Error in main loading:', error);
      
      // Tampilkan error di struktur
      const container = document.getElementById('strukturGrid');
      if (container) {
        container.innerHTML = `
          <div class="error">
            <div style="font-size:48px;margin-bottom:10px;">⚠️</div>
            <p>Error: ${error.message}</p>
            <button onclick="location.reload()" style="
              margin-top: 15px;
              padding: 10px 20px;
              background: #3b82f6;
              color: white;
              border: none;
              border-radius: 8px;
              cursor: pointer;
            ">Refresh Halaman</button>
          </div>
        `;
      }
    }
  }
  
  // ============================================
  // SCROLL ANIMATION (Exclude struktur)
  // ============================================
  
  function setupScrollAnimation() {
    // Hanya section selain struktur
    const sections = document.querySelectorAll('section:not(#struktur)');
    
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
          // observer.unobserve(entry.target); // Tidak di-unobserve agar bisa animasi lagi
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -50px 0px'
    });
    
    sections.forEach(section => observer.observe(section));
    
    // Struktur langsung show tanpa observer
    const strukturSection = document.getElementById('struktur');
    if (strukturSection) {
      strukturSection.classList.add('show');
    }
  }
  
  // ============================================
  // EVENT LISTENERS
  // ============================================
  
  // Close menu when clicking outside
  document.addEventListener('click', (e) => {
    const menu = document.getElementById('navMenu');
    const toggle = document.querySelector('.nav-toggle');
    if (menu && toggle && !menu.contains(e.target) && !toggle.contains(e.target)) {
      menu.classList.remove('show');
    }
  });
  
  // Handle back button/refresh
  window.addEventListener('pageshow', function(event) {
    if (event.persisted) {
      console.log('Page restored from cache, re-rendering...');
      setTimeout(loadAndRenderAllData, 100);
    }
  });
  
  // ============================================
  // INITIALIZE PAGE
  // ============================================
  
  console.log('Initializing page...');
  
  // Setup navigation
  window.toggleMenu = toggleMenu;
  window.scrollToSection = scrollToSection;
  window.glowEffect = glowEffect;
  
  // Mulai load data
  setTimeout(() => {
    loadAndRenderAllData();
  }, 100);
  
  // Re-check data jika page menjadi visible
  document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
      console.log('Page became visible, checking data...');
      // Optional: refresh data
    }
  });
  
  console.log('✅ Page initialization complete');
});