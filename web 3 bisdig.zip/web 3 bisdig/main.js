// ============================================
// LOAD MEDIA DARI DATA.js
// ============================================

function createMediaElement(data) {
  const card = document.createElement('div');
  card.className = 'card';
  card.onclick = function() { glowEffect(this); };

  if (data.type === 'video') {
    card.innerHTML = `<video src="${data.url}" controls preload="metadata" playsinline></video>`;
  } else {
    card.innerHTML = `<img src="${data.url}" alt="${data.caption}">`;
  }

  return card;
}

// Load Foto Terbaru
const fotoGrid = document.getElementById('fotoTerbaruGrid');
fotoTerbaru.forEach(media => {
  fotoGrid.appendChild(createMediaElement(media));
});

// Load Kenangan
const kenanganContainer = document.getElementById('kenanganPreview');
kenangan.forEach(media => {
  kenanganContainer.appendChild(createMediaElement(media));
});

// Load Struktur Kelas
const strukturGrid = document.getElementById('strukturGrid');
strukturKelas.forEach(anggota => {
  const card = document.createElement('div');
  card.className = 'card anggota-card';
  card.onclick = function() { glowEffect(this); };

  const imageContent = anggota.foto 
    ? `<img src="${anggota.foto}" alt="${anggota.nama}">`
    : `<div class="anggota-placeholder">${anggota.initial}</div>`;

  card.innerHTML = `
    ${imageContent}
    <h4>${anggota.nama}</h4>
    <p>${anggota.jabatan}</p>
  `;

  strukturGrid.appendChild(card);
});

// ============================================
// NAVIGATION & EFFECTS
// ============================================

function toggleMenu() {
  const menu = document.getElementById('navMenu');
  menu.classList.toggle('show');
}

function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
  document.getElementById('navMenu').classList.remove('show');
}

let activeCard = null;
function glowEffect(element) {
  if (activeCard) {
    activeCard.classList.remove('active');
  }
  element.classList.add('active');
  activeCard = element;
  
  setTimeout(() => {
    element.classList.remove('active');
    activeCard = null;
  }, 800);
}

// Scroll Animation
const sections = document.querySelectorAll('section');

const observerOptions = {
  threshold: 0.15,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('show');
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);

sections.forEach(section => observer.observe(section));

// Close menu when clicking outside
document.addEventListener('click', (e) => {
  const menu = document.getElementById('navMenu');
  const toggle = document.querySelector('.nav-toggle');
  if (!menu.contains(e.target) && !toggle.contains(e.target)) {
    menu.classList.remove('show');
  }
});