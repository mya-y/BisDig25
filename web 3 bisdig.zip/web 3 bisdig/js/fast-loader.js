// js/fast-loader.js
console.log('⚡ Fast Loader Active');

// 1. CACHE SYSTEM
let CACHE = null;

// 2. LOAD DATA SUPER CEPAT
function loadDataFast() {
  console.log('🚀 Loading data FAST...');
  
  // Jika sudah ada cache, pakai cache
  if (CACHE) {
    console.log('✅ Using cached data');
    return Promise.resolve(CACHE);
  }
  
  // Priority 1: DATA.js (paling cepat)
  if (typeof DATA !== 'undefined' && DATA) {
    console.log('✅ Using DATA.js');
    CACHE = {
      galeri: Array.isArray(DATA.galeri) ? DATA.galeri : [],
      struktur: Array.isArray(DATA.struktur) ? DATA.struktur : [],
      jadwal: Array.isArray(DATA.jadwal) ? DATA.jadwal : [],
      tugas: Array.isArray(DATA.tugas) ? DATA.tugas : [],
      prestasi: Array.isArray(DATA.prestasi) ? DATA.prestasi : []
    };
    return Promise.resolve(CACHE);
  }
  
  // Priority 2: Fallback kosong
  console.log('⚠️ No data found, using empty');
  CACHE = {
    galeri: [],
    struktur: [],
    jadwal: [],
    tugas: [],
    prestasi: []
  };
  return Promise.resolve(CACHE);
}

// 3. RENDER STRUKTUR INSTANT
function renderStrukturInstant(struktur) {
  const container = document.getElementById('strukturGrid');
  if (!container) {
    console.error('Struktur container not found');
    return;
  }
  
  // Kosongkan dulu
  container.innerHTML = '';
  
  // Jika tidak ada data, tampilkan placeholder
  if (!struktur || struktur.length === 0) {
    container.innerHTML = `
      <div style="text-align:center;padding:40px;color:#64748b;grid-column:1/-1;">
        <div style="font-size:48px;margin-bottom:10px;">👥</div>
        <p>Struktur kelas belum diatur</p>
        <p style="font-size:14px;margin-top:10px;">
          <a href="admin.html" style="color:#38bdf8;">Admin</a> → Struktur → Tambah Anggota
        </p>
      </div>
    `;
    return;
  }
  
  // Render langsung tanpa efek
  let html = '';
  struktur.forEach((item, index) => {
    const initial = item.initial || (item.nama ? item.nama.charAt(0).toUpperCase() : '?');
    
    html += `
      <div class="anggota-card" style="
        opacity: 1;
        transform: none;
        animation: fadeIn 0.5s ease ${index * 0.1}s both;
      ">
        ${item.foto ? 
          `<img src="${item.foto}" alt="${item.nama}" loading="lazy" 
               onload="this.style.opacity='1'" 
               style="opacity:1;transition:opacity 0.3s;">` : 
          `<div class="anggota-placeholder">${initial}</div>`
        }
        <h4>${item.nama || 'Anggota'}</h4>
        <p>${item.jabatan || 'Kelas'}</p>
      </div>
    `;
  });
  
  container.innerHTML = html;
  console.log(`✅ Instant rendered ${struktur.length} struktur items`);
}

// 4. INITIALIZE
document.addEventListener('DOMContentLoaded', function() {
  console.log('🏠 Page loaded, starting FAST render...');
  
  // Langsung load data
  loadDataFast().then(data => {
    // RENDER STRUKTUR PERTAMA & CEPAT!
    renderStrukturInstant(data.struktur);
    
    // Render lainnya setelahnya
    setTimeout(() => {
      // Anda bisa tambah render untuk galeri, dll di sini
      console.log('✅ All data loaded FAST');
    }, 50);
  }).catch(error => {
    console.error('❌ Fast load error:', error);
    
    // Fallback: tampilkan struktur kosong
    const container = document.getElementById('strukturGrid');
    if (container) {
      container.innerHTML = `
        <div class="anggota-card"><div class="anggota-placeholder">👑</div><h4>Ketua</h4><p>Sedang dipilih</p></div>
        <div class="anggota-card"><div class="anggota-placeholder">📝</div><h4>Sekretaris</h4><p>Sedang dipilih</p></div>
        <div class="anggota-card"><div class="anggota-placeholder">💰</div><h4>Bendahara</h4><p>Sedang dipilih</p></div>
        <div class="anggota-card"><div class="anggota-placeholder">🎯</div><h4>Anggota</h4><p>Bisnis Digital 25</p></div>
      `;
    }
  });
});

// 5. CSS ANIMATION
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;
document.head.appendChild(style);

// 6. EXPORT
window.FAST_LOADER = {
  loadDataFast,
  renderStrukturInstant,
  CACHE
};