// js/mobile-optimized.js - HP FIX
console.log('📱 Mobile Optimizer Active');

// ============================================
// 1. DETECT MOBILE & LOW POWER
// ============================================
const IS_MOBILE = /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
const IS_SLOW_NETWORK = navigator.connection 
  ? (navigator.connection.effectiveType === 'slow-2g' || 
     navigator.connection.effectiveType === '2g' ||
     navigator.connection.saveData === true)
  : false;

console.log(`📊 Mobile: ${IS_MOBILE}, Slow: ${IS_SLOW_NETWORK}`);

// ============================================
// 2. EXTREME MOBILE OPTIMIZATIONS
// ============================================

// A. DISABLE UNNECESSARY ANIMATIONS ON MOBILE
if (IS_MOBILE) {
  const style = document.createElement('style');
  style.textContent = `
    /* Disable heavy animations on mobile */
    .anggota-card, .photo-card, .card {
      animation: none !important;
      transition: none !important;
      transform: none !important;
      opacity: 1 !important;
    }
    
    /* Reduce image quality for mobile */
    img, video {
      max-width: 100%;
      height: auto;
    }
    
    /* Simplify layout */
    .struktur-grid {
      grid-template-columns: repeat(2, 1fr) !important;
      gap: 10px !important;
    }
    
    /* Remove shadows on mobile */
    .anggota-card, .card {
      box-shadow: none !important;
    }
  `;
  document.head.appendChild(style);
}

// B. LAZY LOAD IMAGES (MOBILE SPECIFIC)
function lazyLoadMobileImages() {
  if (!IS_MOBILE) return;
  
  const images = document.querySelectorAll('img[loading="lazy"]');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        // Load image
        if (img.dataset.src) {
          img.src = img.dataset.src;
        }
        // Show immediately
        img.style.opacity = '1';
        observer.unobserve(img);
      }
    });
  }, {
    rootMargin: '50px',
    threshold: 0.01 // Very sensitive for mobile
  });
  
  images.forEach(img => observer.observe(img));
}

// ============================================
// 3. ULTRA-FAST STRUCTURE RENDER (HP FRIENDLY)
// ============================================

function renderStrukturMobile() {
  console.time('🏗️ Render Struktur Mobile');
  
  const container = document.getElementById('strukturGrid');
  if (!container) {
    console.error('No struktur container');
    return;
  }
  
  // FORCE CONTAINER VISIBLE
  container.style.opacity = '1';
  container.style.visibility = 'visible';
  container.style.display = 'grid';
  container.style.minHeight = '200px';
  
  // 1. Check Data.js FIRST (fastest)
  let strukturData = [];
  
  if (typeof DATA !== 'undefined' && DATA.struktur && DATA.struktur.length > 0) {
    strukturData = DATA.struktur.slice(0, 8); // Max 8 di HP
    console.log(`✅ Using Data.js: ${strukturData.length} items`);
  } else {
    // 2. Fallback: basic structure
    console.log('⚠️ No data, using fallback');
    strukturData = [
      { nama: 'Ketua Kelas', jabatan: 'Pemimpin', initial: 'K' },
      { nama: 'Wakil Ketua', jabatan: 'Wakil', initial: 'W' },
      { nama: 'Sekretaris', jabatan: 'Tulis-menulis', initial: 'S' },
      { nama: 'Bendahara', jabatan: 'Keuangan', initial: 'B' }
    ];
  }
  
  // 3. RENDER SUPER SIMPLE (no animations)
  let html = '';
  strukturData.forEach((item, index) => {
    const initial = item.initial || (item.nama ? item.nama.charAt(0).toUpperCase() : '?');
    
    html += `
      <div class="anggota-card" style="
        opacity: 1;
        transform: none;
        animation: none;
        border: 1px solid rgba(56, 189, 248, 0.2);
        border-radius: 10px;
        overflow: hidden;
        background: rgba(30, 41, 59, 0.8);
      ">
        <div style="
          width: 100%;
          height: 120px;
          background: ${item.foto ? 'transparent' : 'linear-gradient(135deg, #334155, #475569)'};
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2.5em;
          color: #94a3b8;
          border-bottom: 1px solid rgba(56, 189, 248, 0.1);
        ">
          ${item.foto ? 
            `<img src="${item.foto}" alt="${item.nama}" 
                 loading="lazy" 
                 style="width:100%;height:100%;object-fit:cover;opacity:1;">` : 
            initial
          }
        </div>
        <div style="padding: 10px; text-align: center;">
          <h4 style="margin:0 0 5px 0;font-size:0.9em;color:#e5e7eb;">${item.nama || 'Anggota'}</h4>
          <p style="margin:0;font-size:0.8em;color:#94a3b8;">${item.jabatan || 'Kelas'}</p>
        </div>
      </div>
    `;
  });
  
  container.innerHTML = html;
  
  // 4. Force browser to paint NOW
  setTimeout(() => {
    // Trigger reflow
    container.offsetHeight;
    
    // Load images
    lazyLoadMobileImages();
    
    console.timeEnd('🏗️ Render Struktur Mobile');
    console.log(`✅ Mobile: Rendered ${strukturData.length} items`);
  }, 10);
}

// ============================================
// 4. LOADING MANAGEMENT FOR SLOW MOBILE
// ============================================

function manageMobileLoading() {
  // Hide loading screen faster on mobile
  const loadingEl = document.getElementById('globalLoading');
  if (loadingEl && IS_MOBILE) {
    // HP: sembunyikan loading lebih cepat
    setTimeout(() => {
      loadingEl.style.transition = 'opacity 0.3s';
      loadingEl.style.opacity = '0';
      setTimeout(() => {
        loadingEl.style.display = 'none';
      }, 300);
    }, 800); // 0.8 detik saja di HP
  }
  
  // Show content immediately
  document.querySelectorAll('section').forEach(section => {
    section.style.opacity = '1';
    section.style.transform = 'none';
  });
}

// ============================================
// 5. INITIALIZE ON MOBILE
// ============================================

// START IMMEDIATELY (don't wait for DOMContentLoaded)
if (IS_MOBILE) {
  console.log('🚀 Starting mobile-optimized render...');
  
  // 1. Render struktur ASAP
  setTimeout(renderStrukturMobile, 50);
  
  // 2. Manage loading
  setTimeout(manageMobileLoading, 100);
  
  // 3. Add touch optimizations
  document.addEventListener('touchstart', function() {}, { passive: true });
  
  // 4. Prevent zoom on double tap
  document.addEventListener('touchend', function(e) {
    if (e.touches.length === 2) {
      e.preventDefault();
    }
  }, { passive: false });
}

// Export
window.MOBILE_OPTIMIZER = {
  IS_MOBILE,
  IS_SLOW_NETWORK,
  renderStrukturMobile,
  lazyLoadMobileImages
};